### ServerResourcePacks
### 为服务器的资源包"开源"

* 任何人都可以编辑他
* 请在目录ServerResourcePacks\assets\minecraft\mcpatcher\cit下
* 创建一个属于你个人的文件夹然后进行添加材质
* 我创建的是item你的可以是其他
* 之后需要我审核
* 去这里可以看教程
https://www.thelunai.ml/2018/08/ServerResourcePacks/
 
### 下载之后请解压出来并删除README.md再重新打包成zip
## 记住文件夹和文件名字不要有任何的大写   文本内容不限
